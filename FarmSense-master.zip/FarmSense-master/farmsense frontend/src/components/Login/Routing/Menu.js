import React from 'react';

function Menu (){

    return (
        <ul>
            <li><a href="/">Form</a></li>
            <li><a href="/Signup2">Signup2</a></li>
            <li><a href="/Forgot">Forgot</a></li>
            <li><a href="/Dashboard">Dashboard</a></li>
         </ul>
         )
}
    export default Menu