import React from 'react'
import { Link } from 'react-router-dom';
import bgImg from '../../img/Shivam.jpeg';
import { useForm } from 'react-hook-form';
import "../../components/Login/Login.css";
import { useDispatch } from 'react-redux';
import { login } from "../../Reduser/AuthSlice";
import { useNavigate } from 'react-router-dom';
import store from '../../Store';



export default function Form() {
    

    
    
  return (
    <section>
      
        
    </section>
  )
}