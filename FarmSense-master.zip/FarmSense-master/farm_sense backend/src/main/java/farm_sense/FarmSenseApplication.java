package farm_sense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmSenseApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmSenseApplication.class, args);
	}

}
