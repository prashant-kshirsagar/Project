package farm_sense.seqService;

public interface SeqService {

	
	public int generateSequence(String seq_id);
	
}
