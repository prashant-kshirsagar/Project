package farm_sense;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmSenseApplicationTests {

	@Test
	void contextLoads() {
	}

}
